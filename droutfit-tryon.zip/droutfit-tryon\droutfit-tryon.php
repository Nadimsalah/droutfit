<?php
/**
 * Plugin Name: DrOutfit Virtual Try-On
 * Plugin URI: https://droutfit.com
 * Description: AI-Powered Virtual Try-On for WooCommerce.
 * Version: 1.0.0
 * Author: DrOutfit
 * Text Domain: droutfit-tryon
 */

if (!defined('ABSPATH')) exit;

class DrOutfit_TryOn {
    public function __construct() {
        // Add settings page
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_init', [$this, 'settings_init']);

        // Inject button into WooCommerce
        add_action('woocommerce_after_add_to_cart_button', [$this, 'inject_tryon_button']);
        
        // Enqueue scripts
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    public function add_admin_menu() {
        add_options_page(
            'DrOutfit Settings',
            'DrOutfit Try-On',
            'manage_options',
            'droutfit-tryon',
            [$this, 'settings_page']
        );
    }

    public function settings_init() {
        register_setting('droutfit_settings', 'droutfit_engine_url');
        register_setting('droutfit_settings', 'droutfit_merchant_id');

        add_settings_section(
            'droutfit_section',
            'Connection Settings',
            null,
            'droutfit-tryon'
        );

        add_settings_field(
            'droutfit_engine_url',
            'Engine URL (Next.js App)',
            [$this, 'engine_url_render'],
            'droutfit-tryon',
            'droutfit_section'
        );
    }

    public function engine_url_render() {
        $url = get_option('droutfit_engine_url', 'https://your-droutfit-app.vercel.app');
        echo "<input type='url' name='droutfit_engine_url' value='" . esc_attr($url) . "' class='regular-text' placeholder='https://...'>";
    }

    public function settings_page() {
        ?>
        <form action='options.php' method='post'>
            <h1>DrOutfit Virtual Try-On</h1>
            <?php
            settings_fields('droutfit_settings');
            do_settings_sections('droutfit-tryon');
            submit_button();
            ?>
        </form>
        <?php
    }

    public function inject_tryon_button() {
        global $product;
        if (!$product) return;

        $product_id = $product->get_id();
        $engine_url = get_option('droutfit_engine_url');

        if (!$engine_url) return;

        // The widget URL structure: {engine_url}/widget/{product_id}?shop=wordpress
        $widget_url = rtrim($engine_url, '/') . "/widget/" . $product_id . "?shop=wordpress";

        echo '<button type="button" 
                id="droutfit-tryon-btn" 
                class="button alt" 
                style="margin-top: 10px; width: 100%; height: 50px; border-radius: 12px; background: linear-gradient(90deg, #2563eb, #7c3aed); color: white; border: none; font-weight: bold; cursor: pointer; display: flex; items-center: center; justify-content: center; gap: 8px;"
                data-url="' . esc_attr($widget_url) . '">
                <span style="font-size: 1.2em;">✨</span> Virtual Try-On
              </button>';
    }

    public function enqueue_assets() {
        if (is_product()) {
            wp_enqueue_script('droutfit-widget', plugin_dir_url(__FILE__) . 'assets/js/droutfit-widget.js', [], '1.0.0', true);
            wp_enqueue_style('droutfit-style', plugin_dir_url(__FILE__) . 'assets/css/droutfit-style.css');
        }
    }
}

new DrOutfit_TryOn();
