=== DrOutfit Virtual Try-On ===
Contributors: droutfit
Tags: woocommerce, ai, virtual try-on, fashion
Requires at least: 5.0
Tested up to: 6.4
Stable tag: 1.0.0
License: GPLv2 or later

AI-Powered Virtual Try-On for WooCommerce.

== Description ==

This plugin bridges your WooCommerce store with the DrOutfit AI Virtual Try-On engine.

== Installation ==

1. Upload the `droutfit-tryon` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Go to `Settings -> DrOutfit Try-On` and enter your Next.js Engine URL.
4. The "Virtual Try-On" button will automatically appear on your product pages!

== Frequently Asked Questions ==

= Does it require WooCommerce? =
Yes, this plugin is specifically designed to work with WooCommerce product pages.
